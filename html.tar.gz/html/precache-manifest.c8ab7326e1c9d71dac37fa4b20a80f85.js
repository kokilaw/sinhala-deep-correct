self.__precacheManifest = [
  {
    "revision": "e63b93dfac2600782654e2b87910d681",
    "url": "/static/media/Poppins-SemiBold.e63b93df.ttf"
  },
  {
    "revision": "731a28a413d642522667a2de8681ff35",
    "url": "/static/media/Poppins-Regular.731a28a4.ttf"
  },
  {
    "revision": "a4e11dda40531debd374e4c8b1dcc7f4",
    "url": "/static/media/Poppins-Medium.a4e11dda.ttf"
  },
  {
    "revision": "7940efc40d8e3b477e16cc41b0287139",
    "url": "/static/media/Poppins-Bold.7940efc4.ttf"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "c4a094e894f5fdb2e0f3",
    "url": "/static/js/main.21e5ee47.chunk.js"
  },
  {
    "revision": "2160fda4a25971b773a4",
    "url": "/static/js/2.b2a35335.chunk.js"
  },
  {
    "revision": "c4a094e894f5fdb2e0f3",
    "url": "/static/css/main.e84640e9.chunk.css"
  },
  {
    "revision": "e773bde2c3d1432aa160b6c28056e7dc",
    "url": "/index.html"
  }
];