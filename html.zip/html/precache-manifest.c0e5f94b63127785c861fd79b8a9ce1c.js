self.__precacheManifest = [
  {
    "revision": "e63b93dfac2600782654e2b87910d681",
    "url": "/static/media/Poppins-SemiBold.e63b93df.ttf"
  },
  {
    "revision": "731a28a413d642522667a2de8681ff35",
    "url": "/static/media/Poppins-Regular.731a28a4.ttf"
  },
  {
    "revision": "a4e11dda40531debd374e4c8b1dcc7f4",
    "url": "/static/media/Poppins-Medium.a4e11dda.ttf"
  },
  {
    "revision": "7940efc40d8e3b477e16cc41b0287139",
    "url": "/static/media/Poppins-Bold.7940efc4.ttf"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "396767f5f5674cd08060",
    "url": "/static/js/main.ec4d2864.chunk.js"
  },
  {
    "revision": "aa8a0a5356ffcd38bd0e",
    "url": "/static/js/2.648bf552.chunk.js"
  },
  {
    "revision": "396767f5f5674cd08060",
    "url": "/static/css/main.f09b10e8.chunk.css"
  },
  {
    "revision": "8b29f566fedb5f88d71adc74bd26bace",
    "url": "/index.html"
  }
];