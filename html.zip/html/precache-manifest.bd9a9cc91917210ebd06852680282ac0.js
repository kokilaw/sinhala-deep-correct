self.__precacheManifest = [
  {
    "revision": "e63b93dfac2600782654e2b87910d681",
    "url": "/sinhala-grammar-correction-web/static/media/Poppins-SemiBold.e63b93df.ttf"
  },
  {
    "revision": "731a28a413d642522667a2de8681ff35",
    "url": "/sinhala-grammar-correction-web/static/media/Poppins-Regular.731a28a4.ttf"
  },
  {
    "revision": "a4e11dda40531debd374e4c8b1dcc7f4",
    "url": "/sinhala-grammar-correction-web/static/media/Poppins-Medium.a4e11dda.ttf"
  },
  {
    "revision": "7940efc40d8e3b477e16cc41b0287139",
    "url": "/sinhala-grammar-correction-web/static/media/Poppins-Bold.7940efc4.ttf"
  },
  {
    "revision": "514e2493db24c5346a57",
    "url": "/sinhala-grammar-correction-web/static/js/runtime~main.b66e3625.js"
  },
  {
    "revision": "912f47e0b351d61e60d0",
    "url": "/sinhala-grammar-correction-web/static/js/main.d5219638.chunk.js"
  },
  {
    "revision": "ad7eff83eb2c5464bc10",
    "url": "/sinhala-grammar-correction-web/static/js/2.91dc44cb.chunk.js"
  },
  {
    "revision": "912f47e0b351d61e60d0",
    "url": "/sinhala-grammar-correction-web/static/css/main.76728419.chunk.css"
  },
  {
    "revision": "44def49cbdedc50920947bdfc687e22f",
    "url": "/sinhala-grammar-correction-web/index.html"
  }
];